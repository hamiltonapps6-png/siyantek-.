# Siyantek Release Readiness

The Android application is an Expo SDK 57 / React Native 0.86 production project.

## Implemented
- Fresh installs contain no demo vehicle or maintenance records.
- First launch asks the user to configure a vehicle.
- Vehicle and maintenance data are validated before being stored.
- Data is stored locally with AsyncStorage.
- Settings screen includes language selection, privacy information and local-data deletion.
- English, French and Arabic are supported, including RTL layout.
- Android package: `com.siyantek.maintenance`.
- Production build profile outputs an Android App Bundle (AAB).
- Unused sensitive native permissions are blocked in Android configuration.
- Privacy policy text is included in-app and an HTML policy is supplied for hosting.
- Store listing draft and Play release checklist are supplied.

## Current platform requirements
Google Play requires new apps and updates submitted from August 31, 2026 to target Android 16 / API 36 or higher. Expo SDK 57 uses compile/target SDK 36. Google Play also requires native-code apps to support 64-bit architectures and 16 KB memory page sizes.

## Items that cannot be completed without the developer account
1. Publish the privacy policy at a real HTTPS URL.
2. Enter the final developer support email and verified developer identity in Play Console.
3. Create/link the Expo/EAS project and signing credentials.
4. Run a cloud production build and upload the resulting AAB to an internal testing track.
5. Complete Play Console declarations: Data Safety, Content Rating, Target Audience, Ads, and app access/reviewer instructions as applicable.
6. Perform device testing on the final signed build.

No tool can guarantee Google Play acceptance; final approval is made by Google based on the submitted build, store metadata, developer account verification and policy declarations.
