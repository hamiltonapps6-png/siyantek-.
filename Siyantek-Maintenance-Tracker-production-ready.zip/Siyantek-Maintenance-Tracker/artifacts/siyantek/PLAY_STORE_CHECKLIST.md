# Siyantek — Google Play release checklist

## Developer-provided items
- [ ] Verify Google Play developer account identity and contact details.
- [ ] Publish `PRIVACY_POLICY.md` at a stable HTTPS URL and put the same URL in Play Console.
- [ ] Add support email and developer contact details.
- [ ] Prepare store icon, feature graphic and screenshots.
- [ ] Complete Content Rating questionnaire.
- [ ] Complete Data Safety form based on the final production build.
- [ ] Declare ads: No, if the released build contains no ads.
- [ ] Declare target audience accurately.
- [ ] Provide reviewer instructions only if the final app contains restricted access.

## Technical release
- [ ] Build an Android App Bundle (AAB) with EAS production profile.
- [ ] Confirm package name: `com.siyantek.maintenance`.
- [ ] Increment `android.versionCode` for every Play upload when using a local version source, or keep EAS remote auto-increment enabled.
- [ ] Confirm target API 36 or higher.
- [ ] Confirm 64-bit support and 16 KB page-size compatibility for native code.
- [ ] Test on at least one Android 13/14/15/16 device or emulator.
- [ ] Test first launch, Arabic RTL, French, English, keyboard entry, rotation/resizing where applicable, and offline persistence.
- [ ] Verify no demo/sample vehicle or maintenance records ship in a fresh install.
- [ ] Verify app can be used without network access.
- [ ] Upload AAB to an internal testing track before production.
