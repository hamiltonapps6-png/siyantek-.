/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Siyantek uses deep ink with workshop teal and a warm service amber.
    text: '#102A35',
    tint: '#16A6A0',

    // Core surfaces
    background: '#F4F7F5',
    foreground: '#102A35',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#102A35',

    // Primary action color (buttons, links, active states)
    primary: '#16A6A0',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#E7EFEC',
    secondaryForeground: '#16404A',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#EDF2F0',
    mutedForeground: '#668087',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#FFF1D8',
    accentForeground: '#8A5B16',

    // Destructive actions (delete, error states)
    destructive: '#C94E4E',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#DCE7E3',
    input: '#D2E1DC',
    navy: '#102A35',
    teal: '#16A6A0',
    tealSoft: '#DDF4EF',
    amber: '#F2B45C',
    amberSoft: '#FFF1D8',
    green: '#2B9A70',
    greenSoft: '#E2F5EB',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 8,
};

export default colors;
