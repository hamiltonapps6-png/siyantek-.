# Siyantek Privacy Policy

**Last updated: September 29, 2026**

Siyantek is a vehicle maintenance tracker designed to work without an account.

## Information stored

Siyantek stores the vehicle information and maintenance records that you enter, such as vehicle make, model, year, registration number, mileage, service type, date, cost and notes.

## Where information is stored

This information is stored locally on the Android device using the app's local storage. Siyantek does not require an account and does not transmit these maintenance records to a Siyantek server.

## Permissions

The production Android app does not request access to contacts, call logs, SMS, precise location, camera or photo library unless a future version explicitly adds a feature that requires one of these permissions and updates this policy.

## Data sharing

Siyantek does not sell, rent or share your vehicle or maintenance records with third parties.

## Data deletion

You can delete all locally stored vehicle and maintenance data from **Settings → Clear all data** inside the app. Uninstalling the app also removes its local app data according to Android's normal application-data behavior.

## Children's privacy

Siyantek is not designed to collect personal information from children and does not require an account.

## Changes

This policy may be updated when the app's data practices change. The effective date will be updated whenever a material change is made.

## Contact

For privacy questions, contact the developer using the support email published on the Google Play store listing.
