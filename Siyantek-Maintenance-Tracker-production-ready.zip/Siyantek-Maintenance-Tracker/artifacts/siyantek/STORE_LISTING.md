# Siyantek — suggested Google Play listing

## App name
Siyantek

## Short description
Track your vehicle mileage, maintenance history and upcoming service intervals offline.

## Full description
Siyantek is a simple vehicle maintenance tracker built for everyday drivers.

Keep your vehicle information and service history organized in one place:

- Track current mileage.
- Record oil changes, brakes, tires, inspections, batteries and other maintenance.
- Save service date, mileage, cost and notes.
- Set the next service mileage.
- Review recent maintenance and full history.
- Use the app offline; your records stay on your device.
- Switch between English, French and Arabic.
- Use Arabic RTL layout.
- Clear all locally stored data from Settings at any time.

Siyantek does not require an account and does not contain advertising in the production build described by this listing.
