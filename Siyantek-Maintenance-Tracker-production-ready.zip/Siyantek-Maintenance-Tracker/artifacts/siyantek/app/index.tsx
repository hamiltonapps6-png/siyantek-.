import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Constants from 'expo-constants';
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { Language, MaintenanceType, Vehicle, formatLocalizedNumber, useSiyantek } from '@/context/SiyantekContext';
import { useColors } from '@/hooks/useColors';

const TYPES: { key: MaintenanceType; icon: keyof typeof Feather.glyphMap }[] = [
  { key: 'oil', icon: 'droplet' },
  { key: 'brakes', icon: 'disc' },
  { key: 'tires', icon: 'circle' },
  { key: 'inspection', icon: 'clipboard' },
  { key: 'battery', icon: 'battery' },
  { key: 'other', icon: 'tool' },
];

const dateLabel = (value: string, language: Language) => {
  const date = new Date(`${value}T12:00:00`);
  return new Intl.DateTimeFormat(language === 'ar' ? 'ar-TN' : language === 'fr' ? 'fr-FR' : 'en-US', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date);
};

const daysSince = (value: string) => Math.max(0, Math.round((Date.now() - new Date(`${value}T12:00:00`).getTime()) / 86400000));

function LogoMark({ colors }: { colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[styles.logoMark, { backgroundColor: colors.teal }]}>
      <Feather name="activity" size={20} color={colors.primaryForeground} strokeWidth={2.5} />
    </View>
  );
}

function LanguagePicker() {
  const { language, setLanguage, isRTL } = useSiyantek();
  const colors = useColors();
  const languages: { key: Language; label: string }[] = [
    { key: 'en', label: 'EN' },
    { key: 'fr', label: 'FR' },
    { key: 'ar', label: 'ع' },
  ];
  return (
    <View style={[styles.languagePicker, { backgroundColor: colors.card, borderColor: colors.border }, isRTL && { flexDirection: 'row-reverse' }]}>
      {languages.map((item) => {
        const selected = item.key === language;
        return (
          <Pressable
            key={item.key}
            testID={`language-${item.key}`}
            accessibilityRole="button"
            onPress={() => {
              Haptics.selectionAsync();
              setLanguage(item.key);
            }}
            style={[styles.languageButton, selected && { backgroundColor: colors.navy }]}
          >
            <Text style={[styles.languageLabel, { color: selected ? colors.primaryForeground : colors.mutedForeground }]}>{item.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

function StatPill({ icon, label, value, colors }: { icon: keyof typeof Feather.glyphMap; label: string; value: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[styles.statPill, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.statIcon, { backgroundColor: colors.tealSoft }]}>
        <Feather name={icon} size={15} color={colors.teal} />
      </View>
      <View style={styles.statCopy}>
        <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
        <Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text>
      </View>
    </View>
  );
}

function TypeIcon({ type, colors }: { type: MaintenanceType; colors: ReturnType<typeof useColors> }) {
  const item = TYPES.find((entry) => entry.key === type) ?? TYPES[5];
  return (
    <View style={[styles.activityIcon, { backgroundColor: type === 'oil' ? colors.amberSoft : colors.tealSoft }]}>
      <Feather name={item.icon} size={17} color={type === 'oil' ? colors.accentForeground : colors.teal} />
    </View>
  );
}

function AddMaintenanceModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const colors = useColors();
  const { addRecord, language, t, vehicle, isRTL } = useSiyantek();
  const [type, setType] = useState<MaintenanceType>('oil');
  const [mileage, setMileage] = useState(String(vehicle.mileage));
  const [cost, setCost] = useState('');
  const [notes, setNotes] = useState('');
  const [nextMileage, setNextMileage] = useState('');
  const [error, setError] = useState('');

  const closeAndReset = () => {
    setType('oil');
    setMileage(String(vehicle.mileage));
    setCost('');
    setNotes('');
    setNextMileage('');
    setError('');
    onClose();
  };

  const save = () => {
    const parsedMileage = Number(mileage.replace(/[^\d.]/g, ''));
    if (!mileage.trim()) {
      setError(t('requiredMileage'));
      return;
    }
    if (!Number.isFinite(parsedMileage) || parsedMileage <= 0) {
      setError(t('invalidMileage'));
      return;
    }
    const parsedNextMileage = nextMileage.trim()
      ? Number(nextMileage.replace(/[^\d.]/g, ''))
      : undefined;
    if (
      parsedNextMileage !== undefined &&
      (!Number.isFinite(parsedNextMileage) || parsedNextMileage <= parsedMileage)
    ) {
      setError(t('invalidNextMileage'));
      return;
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    addRecord({
      type,
      mileage: parsedMileage,
      date: new Date().toISOString().slice(0, 10),
      cost: Number(cost.replace(/[^\d.]/g, '')) || 0,
      notes: notes.trim(),
      nextMileage: parsedNextMileage,
    });
    closeAndReset();
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={closeAndReset}>
      <View style={[styles.modalRoot, { backgroundColor: colors.background }]}>
        <View style={[styles.modalHeader, { borderBottomColor: colors.border }, isRTL && { flexDirection: 'row-reverse' }]}>
          <View>
            <Text style={[styles.modalEyebrow, { color: colors.teal, textAlign: isRTL ? 'right' : 'left' }]}>{t('service')}</Text>
            <Text style={[styles.modalTitle, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('addServiceTitle')}</Text>
          </View>
          <Pressable testID="close-maintenance" onPress={closeAndReset} style={[styles.closeButton, { backgroundColor: colors.secondary }]}>
            <Feather name="x" size={19} color={colors.foreground} />
          </Pressable>
        </View>
        <KeyboardAwareScrollViewCompat
          bottomOffset={80}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[styles.modalContent, { paddingBottom: 32 }, isRTL && { direction: 'rtl' }]}
        >
          <Text style={[styles.fieldLabel, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('serviceType')}</Text>
          <View style={[styles.typeGrid, isRTL && { flexDirection: 'row-reverse' }]}>
            {TYPES.map((item) => {
              const selected = item.key === type;
              return (
                <Pressable
                  key={item.key}
                  testID={`maintenance-type-${item.key}`}
                  onPress={() => setType(item.key)}
                  style={[styles.typeChoice, { borderColor: selected ? colors.teal : colors.border, backgroundColor: selected ? colors.tealSoft : colors.card }]}
                >
                  <Feather name={item.icon} size={18} color={selected ? colors.teal : colors.mutedForeground} />
                  <Text style={[styles.typeChoiceText, { color: selected ? colors.teal : colors.foreground }]}>{t(item.key)}</Text>
                </Pressable>
              );
            })}
          </View>

          <Text style={[styles.fieldLabel, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('mileage')}</Text>
          <TextInput
            testID="maintenance-mileage"
            value={mileage}
            onChangeText={(value) => { setMileage(value); setError(''); }}
            keyboardType="numeric"
            placeholder={t('enterMileage')}
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { color: colors.foreground, borderColor: error ? colors.destructive : colors.input, backgroundColor: colors.card, textAlign: isRTL ? 'right' : 'left' }]}
          />
          {error ? <Text style={[styles.errorText, { color: colors.destructive, textAlign: isRTL ? 'right' : 'left' }]}>{error}</Text> : null}

          <View style={[styles.fieldRow, isRTL && { flexDirection: 'row-reverse' }]}>
            <View style={styles.fieldHalf}>
              <Text style={[styles.fieldLabel, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('cost')}</Text>
              <TextInput
                testID="maintenance-cost"
                value={cost}
                onChangeText={setCost}
                keyboardType="numeric"
                placeholder={t('enterCost')}
                placeholderTextColor={colors.mutedForeground}
                style={[styles.input, { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card, textAlign: isRTL ? 'right' : 'left' }]}
              />
            </View>
            <View style={styles.fieldHalf}>
              <Text style={[styles.fieldLabel, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('nextMileage')}</Text>
              <TextInput
                testID="maintenance-next-mileage"
                value={nextMileage}
                onChangeText={setNextMileage}
                keyboardType="numeric"
                placeholder={t('enterNextMileage')}
                placeholderTextColor={colors.mutedForeground}
                style={[styles.input, { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card, textAlign: isRTL ? 'right' : 'left' }]}
              />
            </View>
          </View>

          <Text style={[styles.fieldLabel, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('notes')}</Text>
          <TextInput
            testID="maintenance-notes"
            value={notes}
            onChangeText={setNotes}
            multiline
            numberOfLines={4}
            placeholder={t('addNotes')}
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, styles.notesInput, { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card, textAlign: isRTL ? 'right' : 'left' }]}
          />

          <Pressable
            testID="save-maintenance"
            onPress={save}
            style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.teal, opacity: pressed ? 0.84 : 1 }]}
          >
            <Feather name="check" size={18} color={colors.primaryForeground} />
            <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>{t('saveMaintenance')}</Text>
          </Pressable>
          <Pressable onPress={closeAndReset} style={styles.cancelButton}>
            <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>{t('cancel')}</Text>
          </Pressable>
        </KeyboardAwareScrollViewCompat>
      </View>
    </Modal>
  );
}

function VehicleModal({ visible, onClose, onSaved }: { visible: boolean; onClose: () => void; onSaved: (mileage: number) => void }) {
  const colors = useColors();
  const { vehicle, updateVehicle, t, isRTL } = useSiyantek();
  const [form, setForm] = useState<Vehicle>(vehicle);
  useEffect(() => {
    if (visible) setForm(vehicle);
  }, [visible, vehicle]);

  const update = (key: keyof typeof form, value: string | number) => setForm((current) => ({ ...current, [key]: value }));
  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={[styles.modalRoot, { backgroundColor: colors.background }]}>
        <View style={[styles.modalHeader, { borderBottomColor: colors.border }, isRTL && { flexDirection: 'row-reverse' }]}>
          <View>
            <Text style={[styles.modalEyebrow, { color: colors.teal }]}>{t('yourCar')}</Text>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>{t('vehicleDetails')}</Text>
          </View>
          <Pressable onPress={onClose} style={[styles.closeButton, { backgroundColor: colors.secondary }]}>
            <Feather name="x" size={19} color={colors.foreground} />
          </Pressable>
        </View>
        <KeyboardAwareScrollViewCompat contentContainerStyle={styles.modalContent} bottomOffset={60} keyboardShouldPersistTaps="handled">
          {(['brand', 'model', 'year', 'plate'] as const).map((key) => (
            <View key={key}>
              <Text style={[styles.fieldLabel, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t(key)}</Text>
              <TextInput
                value={String(form[key])}
                onChangeText={(value) => update(key, value)}
                placeholder={t(key)}
                placeholderTextColor={colors.mutedForeground}
                style={[styles.input, { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card, textAlign: isRTL ? 'right' : 'left' }]}
              />
            </View>
          ))}
          <Text style={[styles.fieldLabel, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('currentMileage')}</Text>
          <TextInput
            value={String(form.mileage)}
            onChangeText={(value) => update('mileage', Number(value.replace(/[^\d.]/g, '')) || 0)}
            keyboardType="numeric"
            style={[styles.input, { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card, textAlign: isRTL ? 'right' : 'left' }]}
          />
          <Pressable
            onPress={() => {
              if (!form.brand.trim() || !form.model.trim()) {
                Alert.alert(t('requiredVehicle'));
                return;
              }
              if (form.mileage < 0) {
                Alert.alert(t('invalidMileage'));
                return;
              }
              updateVehicle({ ...form, brand: form.brand.trim(), model: form.model.trim(), year: form.year.trim(), plate: form.plate.trim() });
              onSaved(form.mileage);
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              onClose();
            }}
            style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.teal, opacity: pressed ? 0.84 : 1 }]}
          >
            <Feather name="save" size={18} color={colors.primaryForeground} />
            <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>{t('saveChanges')}</Text>
          </Pressable>
        </KeyboardAwareScrollViewCompat>
      </View>
    </Modal>
  );
}

function SettingsModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const colors = useColors();
  const { language, setLanguage, t, isRTL, resetAllData } = useSiyantek();
  const [privacyVisible, setPrivacyVisible] = useState(false);
  const version = Constants.expoConfig?.version ?? '1.0.0';

  const clearData = () => {
    Alert.alert(t('clearData'), t('clearDataConfirm'), [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('clearData'),
        style: 'destructive',
        onPress: async () => {
          await resetAllData();
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          Alert.alert(t('clearDataDone'));
          onClose();
        },
      },
    ]);
  };

  return (
    <>
      <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
        <View style={[styles.modalRoot, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }, isRTL && { flexDirection: 'row-reverse' }]}>
            <View>
              <Text style={[styles.modalEyebrow, { color: colors.teal }]}>{t('appName')}</Text>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>{t('settings')}</Text>
            </View>
            <Pressable onPress={onClose} style={[styles.closeButton, { backgroundColor: colors.secondary }]} accessibilityLabel={t('close')}>
              <Feather name="x" size={19} color={colors.foreground} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={styles.modalContent}>
            <Text style={[styles.fieldLabel, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('language')}</Text>
            <View style={[styles.settingsLanguageRow, isRTL && { flexDirection: 'row-reverse' }]}>
              {(['fr', 'en', 'ar'] as Language[]).map((item) => (
                <Pressable key={item} onPress={() => setLanguage(item)} style={[styles.settingsLanguageButton, { borderColor: language === item ? colors.teal : colors.border, backgroundColor: language === item ? colors.tealSoft : colors.card }]}>
                  <Text style={[styles.settingsLanguageText, { color: language === item ? colors.teal : colors.foreground }]}>{item === 'ar' ? 'العربية' : item === 'fr' ? 'Français' : 'English'}</Text>
                </Pressable>
              ))}
            </View>

            <Pressable onPress={() => setPrivacyVisible(true)} style={[styles.settingsRow, { backgroundColor: colors.card, borderColor: colors.border }, isRTL && { flexDirection: 'row-reverse' }]}>
              <View style={[styles.settingsIcon, { backgroundColor: colors.tealSoft }]}><Feather name="shield" size={17} color={colors.teal} /></View>
              <View style={styles.settingsCopy}>
                <Text style={[styles.settingsTitle, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('privacy')}</Text>
                <Text style={[styles.settingsSubtitle, { color: colors.mutedForeground, textAlign: isRTL ? 'right' : 'left' }]}>{t('privacyBody')}</Text>
              </View>
              <Feather name={isRTL ? 'chevron-left' : 'chevron-right'} size={18} color={colors.mutedForeground} />
            </Pressable>

            <Pressable onPress={clearData} style={[styles.settingsRow, { backgroundColor: colors.card, borderColor: colors.border }, isRTL && { flexDirection: 'row-reverse' }]}>
              <View style={[styles.settingsIcon, { backgroundColor: colors.destructive + '16' }]}><Feather name="trash-2" size={17} color={colors.destructive} /></View>
              <View style={styles.settingsCopy}>
                <Text style={[styles.settingsTitle, { color: colors.destructive, textAlign: isRTL ? 'right' : 'left' }]}>{t('clearData')}</Text>
              </View>
            </Pressable>

            <Text style={[styles.versionText, { color: colors.mutedForeground }]}>{t('appVersion')} {version}</Text>
          </ScrollView>
        </View>
      </Modal>

      <Modal visible={privacyVisible} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setPrivacyVisible(false)}>
        <View style={[styles.modalRoot, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }, isRTL && { flexDirection: 'row-reverse' }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>{t('privacyTitle')}</Text>
            <Pressable onPress={() => setPrivacyVisible(false)} style={[styles.closeButton, { backgroundColor: colors.secondary }]}>
              <Feather name="x" size={19} color={colors.foreground} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={styles.privacyContent}>
            <Text style={[styles.privacyText, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('privacyBody')}</Text>
            <Text style={[styles.privacyText, { color: colors.mutedForeground, textAlign: isRTL ? 'right' : 'left' }]}>{t('clearData')} : {t('clearDataConfirm')}</Text>
          </ScrollView>
        </View>
      </Modal>
    </>
  );
}

const greetingKey = (hour: number) =>
  hour < 12 ? 'goodMorning' : hour < 18 ? 'goodAfternoon' : 'goodEvening';

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { language, vehicle, records, t, isRTL, updateVehicle, isHydrated } = useSiyantek();
  const [modalVisible, setModalVisible] = useState(false);
  const [vehicleModalVisible, setVehicleModalVisible] = useState(false);
  const [settingsVisible, setSettingsVisible] = useState(false);
  const [viewMode, setViewMode] = useState<'overview' | 'history'>('overview');
  const [mileageDraft, setMileageDraft] = useState(() => String(vehicle.mileage));
  const [mileageError, setMileageError] = useState('');

  useEffect(() => {
    if (isHydrated && (!vehicle.brand.trim() || !vehicle.model.trim())) {
      setVehicleModalVisible(true);
    }
  }, [isHydrated, vehicle.brand, vehicle.model]);

  useEffect(() => {
    setMileageDraft(vehicle.mileage > 0 ? String(vehicle.mileage) : '');
  }, [vehicle.mileage]);

  const sortedRecords = useMemo(() => [...records].sort((a, b) => b.date.localeCompare(a.date)), [records]);
  const latest = sortedRecords[0];
  const nextMileage = latest?.nextMileage ?? (latest ? latest.mileage + 5000 : vehicle.mileage + 5000);
  const distanceToNext = Math.max(0, nextMileage - vehicle.mileage);
  const serviceProgress = Math.min(1, Math.max(0, 1 - distanceToNext / 5000));

  const openAdd = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setModalVisible(true);
  };

  const saveMileage = () => {
    const parsedMileage = Number(mileageDraft.replace(/[^\d.]/g, ''));
    if (!Number.isFinite(parsedMileage) || parsedMileage <= 0) {
      setMileageError(t('invalidMileage'));
      return;
    }
    updateVehicle({ ...vehicle, mileage: parsedMileage });
    setMileageDraft(String(parsedMileage));
    setMileageError('');
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top }, isRTL && { direction: 'rtl' }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 34 },
          Platform.OS === 'web' && { paddingTop: 67, paddingBottom: 34 },
        ]}
      >
        <View style={[styles.topBar, isRTL && { flexDirection: 'row-reverse' }]}>
          <View style={[styles.brandGroup, isRTL && { flexDirection: 'row-reverse' }]}>
            <LogoMark colors={colors} />
            <View>
              <Text style={[styles.brandName, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('appName')}</Text>
              <Text style={[styles.brandTagline, { color: colors.mutedForeground, textAlign: isRTL ? 'right' : 'left' }]}>{t('tagline')}</Text>
            </View>
          </View>
          <View style={[styles.topActions, isRTL && { flexDirection: 'row-reverse' }]}>
            <LanguagePicker />
            <Pressable onPress={() => setSettingsVisible(true)} accessibilityLabel={t('settings')} style={[styles.settingsButton, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="settings" size={17} color={colors.foreground} />
            </Pressable>
          </View>
        </View>

        <View style={[styles.welcomeRow, isRTL && { flexDirection: 'row-reverse' }]}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.teal, textAlign: isRTL ? 'right' : 'left' }]}>{t(greetingKey(new Date().getHours()))}</Text>
            <Text style={[styles.pageTitle, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('yourCar')}</Text>
          </View>
          <Pressable
            testID="edit-vehicle"
            accessibilityLabel={t('editVehicle')}
            onPress={() => setVehicleModalVisible(true)}
            style={({ pressed }) => [styles.editButton, { backgroundColor: colors.tealSoft, borderColor: colors.teal, opacity: pressed ? 0.76 : 1 }, isRTL && { flexDirection: 'row-reverse' }]}
          >
            <Feather name="edit-2" size={15} color={colors.teal} />
            <Text style={[styles.editButtonText, { color: colors.teal }]}>{t('editVehicle')}</Text>
          </Pressable>
        </View>

        <Pressable onPress={() => setVehicleModalVisible(true)} style={[styles.vehicleCard, { backgroundColor: colors.navy }, isRTL && { flexDirection: 'row-reverse' }]}>
          <View style={styles.vehicleCardCopy}>
            <Text style={styles.vehicleLabel}>{vehicle.brand ? `${vehicle.brand.toUpperCase()}${vehicle.year ? ` · ${vehicle.year}` : ''}` : t('noVehicle')}</Text>
            <Text style={styles.vehicleName}>{vehicle.model || t('noVehicle')}</Text>
            <View style={[styles.plateRow, isRTL && { flexDirection: 'row-reverse' }]}>
              <Feather name="credit-card" size={13} color={colors.amber} />
              <Text style={styles.plateText}>{vehicle.plate || t('noVehicleHint')}</Text>
            </View>
          </View>
          <View style={styles.vehicleIllustration}>
            <MaterialCommunityIcons name="car-hatchback" size={70} color={colors.teal} />
            <View style={styles.illustrationGlow} />
          </View>
        </Pressable>

        <View style={[styles.viewSwitch, { backgroundColor: colors.secondary }, isRTL && { flexDirection: 'row-reverse' }]}>
          {(['overview', 'history'] as const).map((mode) => (
            <Pressable key={mode} onPress={() => setViewMode(mode)} style={[styles.viewSwitchButton, viewMode === mode && { backgroundColor: colors.card }]}>
              <Text style={[styles.viewSwitchText, { color: viewMode === mode ? colors.foreground : colors.mutedForeground }]}>{t(mode)}</Text>
            </Pressable>
          ))}
        </View>

        {viewMode === 'overview' ? (
          <>
            <View style={[styles.mileageCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={[styles.cardHeaderRow, isRTL && { flexDirection: 'row-reverse' }]}>
                <View>
                  <Text style={[styles.cardEyebrow, { color: colors.mutedForeground, textAlign: isRTL ? 'right' : 'left' }]}>{t('currentMileage')}</Text>
                  <View style={[styles.mileageValueRow, isRTL && { flexDirection: 'row-reverse' }]}>
                    <Text style={[styles.mileageValue, { color: colors.foreground }]}>{formatLocalizedNumber(vehicle.mileage, language)}</Text>
                    <Text style={[styles.mileageUnit, { color: colors.teal }]}>{t('kilometers')}</Text>
                  </View>
                </View>
                <View style={[styles.mileageBadge, { backgroundColor: colors.greenSoft }]}>
                  <Feather name="trending-up" size={14} color={colors.green} />
                  <Text style={[styles.mileageBadgeText, { color: colors.green }]}>+{formatLocalizedNumber(240, language)}</Text>
                </View>
              </View>
              <View style={[styles.mileageUpdateRow, isRTL && { flexDirection: 'row-reverse' }]}>
                <View style={styles.mileageInputWrap}>
                  <Feather name="edit-3" size={14} color={colors.teal} />
                  <TextInput
                    testID="dashboard-mileage-input"
                    value={mileageDraft}
                    onChangeText={(value) => { setMileageDraft(value); setMileageError(''); }}
                    keyboardType="numeric"
                    placeholder={t('enterMileage')}
                    placeholderTextColor={colors.mutedForeground}
                    style={[styles.mileageInput, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}
                  />
                </View>
                <Pressable
                  testID="dashboard-mileage-save"
                  accessibilityLabel={t('updateMileage')}
                  onPress={saveMileage}
                  style={({ pressed }) => [styles.mileageSaveButton, { backgroundColor: colors.teal, opacity: pressed ? 0.78 : 1 }]}
                >
                  <Feather name="check" size={16} color={colors.primaryForeground} />
                </Pressable>
              </View>
              {mileageError ? <Text style={[styles.mileageError, { color: colors.destructive, textAlign: isRTL ? 'right' : 'left' }]}>{mileageError}</Text> : null}
              <View style={styles.progressTrack}>
                <View style={[styles.progressFill, { backgroundColor: colors.teal, width: `${Math.max(8, serviceProgress * 100)}%` }]} />
              </View>
              <View style={[styles.progressLabels, isRTL && { flexDirection: 'row-reverse' }]}>
                <Text style={[styles.progressText, { color: colors.mutedForeground }]}>{t('lastService')} · {latest ? dateLabel(latest.date, language) : '—'}</Text>
                <Text style={[styles.progressText, { color: colors.teal }]}>{t('nextService')} · {formatLocalizedNumber(nextMileage, language)} {t('kilometers')}</Text>
              </View>
            </View>

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={[styles.statGrid, isRTL && { flexDirection: 'row-reverse' }]}
            >
              <StatPill icon="check-circle" label={t('vehicleHealth')} value={t('onTrack')} colors={colors} />
              <StatPill icon="calendar" label={t('nextService')} value={distanceToNext > 0 ? `${formatLocalizedNumber(distanceToNext, language)} ${t('kilometers')}` : t('allCaughtUp')} colors={colors} />
            </ScrollView>

            <Pressable
              testID="add-maintenance"
              onPress={openAdd}
              style={({ pressed }) => [styles.addButton, { backgroundColor: colors.amber, opacity: pressed ? 0.86 : 1 }, isRTL && { flexDirection: 'row-reverse' }]}
            >
              <View style={styles.addButtonIcon}><Feather name="plus" size={20} color={colors.navy} /></View>
              <Text style={[styles.addButtonText, { color: colors.navy }]}>{t('addMaintenance')}</Text>
              <Feather name={isRTL ? 'arrow-left' : 'arrow-right'} size={19} color={colors.navy} />
            </Pressable>

            <View style={[styles.sectionHeader, isRTL && { flexDirection: 'row-reverse' }]}>
              <Text style={[styles.sectionTitle, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('recentActivity')}</Text>
              <Pressable onPress={() => setViewMode('history')}><Text style={[styles.seeAll, { color: colors.teal }]}>{t('history')}</Text></Pressable>
            </View>
            {sortedRecords.slice(0, 3).map((record) => (
              <View key={record.id} style={[styles.activityRow, { backgroundColor: colors.card, borderColor: colors.border }, isRTL && { flexDirection: 'row-reverse' }]}>
                <TypeIcon type={record.type} colors={colors} />
                <View style={styles.activityCopy}>
                  <Text style={[styles.activityTitle, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t(record.type)}</Text>
                  <Text style={[styles.activityMeta, { color: colors.mutedForeground, textAlign: isRTL ? 'right' : 'left' }]}>{dateLabel(record.date, language)} · {formatLocalizedNumber(record.mileage, language)} {t('kilometers')}</Text>
                </View>
                {record.cost > 0 ? <Text style={[styles.activityCost, { color: colors.foreground }]}>{formatLocalizedNumber(record.cost, language)} DT</Text> : null}
              </View>
            ))}
            {sortedRecords.length === 0 ? (
              <View style={[styles.emptyState, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Feather name="clipboard" size={24} color={colors.teal} />
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{t('noRecords')}</Text>
                <Text style={[styles.emptyHint, { color: colors.mutedForeground }]}>{t('noRecordsHint')}</Text>
              </View>
            ) : null}
          </>
        ) : (
          <View>
            <View style={[styles.historyHeader, isRTL && { flexDirection: 'row-reverse' }]}>
              <Text style={[styles.sectionTitle, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t('maintenanceHistory')}</Text>
              <Text style={[styles.recordCount, { color: colors.mutedForeground }]}>{records.length} {t('recordCount')}</Text>
            </View>
            {sortedRecords.map((record) => (
              <View key={record.id} style={[styles.historyCard, { backgroundColor: colors.card, borderColor: colors.border }, isRTL && { flexDirection: 'row-reverse' }]}>
                <TypeIcon type={record.type} colors={colors} />
                <View style={styles.historyCopy}>
                  <Text style={[styles.activityTitle, { color: colors.foreground, textAlign: isRTL ? 'right' : 'left' }]}>{t(record.type)}</Text>
                  <Text style={[styles.activityMeta, { color: colors.mutedForeground, textAlign: isRTL ? 'right' : 'left' }]}>{dateLabel(record.date, language)} · {formatLocalizedNumber(record.mileage, language)} {t('kilometers')}</Text>
                  {record.notes ? <Text style={[styles.noteText, { color: colors.mutedForeground, textAlign: isRTL ? 'right' : 'left' }]}>{record.notes}</Text> : null}
                </View>
                {record.cost > 0 ? <Text style={[styles.historyCost, { color: colors.foreground }]}>{formatLocalizedNumber(record.cost, language)} DT</Text> : null}
              </View>
            ))}
          </View>
        )}

        <View style={[styles.offlineNote, isRTL && { flexDirection: 'row-reverse' }]}>
          <Feather name="wifi-off" size={14} color={colors.mutedForeground} />
          <Text style={[styles.offlineText, { color: colors.mutedForeground }]}>{t('offline')}</Text>
          {latest ? <Text style={[styles.offlineText, { color: colors.mutedForeground }]}>· {daysSince(latest.date)} {t('ago')}</Text> : null}
        </View>
      </ScrollView>
      <AddMaintenanceModal visible={modalVisible} onClose={() => setModalVisible(false)} />
      <VehicleModal
        visible={vehicleModalVisible}
        onClose={() => setVehicleModalVisible(false)}
        onSaved={(mileage) => setMileageDraft(String(mileage))}
      />
      <SettingsModal visible={settingsVisible} onClose={() => setSettingsVisible(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  scrollContent: { paddingHorizontal: 20, paddingTop: 20 },
  topBar: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 28 },
  brandGroup: { alignItems: 'center', flexDirection: 'row', gap: 10 },
  logoMark: { alignItems: 'center', borderRadius: 13, height: 42, justifyContent: 'center', width: 42 },
  brandName: { fontSize: 20, fontWeight: '700', letterSpacing: -0.4 },
  brandTagline: { fontSize: 10, fontWeight: '500', marginTop: 2 },
  topActions: { alignItems: 'center', flexDirection: 'row', gap: 8 },
  settingsButton: { alignItems: 'center', borderRadius: 18, borderWidth: 1, height: 36, justifyContent: 'center', width: 36 },
  languagePicker: { alignItems: 'center', borderRadius: 18, borderWidth: 1, flexDirection: 'row', padding: 3 },
  languageButton: { alignItems: 'center', borderRadius: 14, height: 28, justifyContent: 'center', minWidth: 31, paddingHorizontal: 7 },
  languageLabel: { fontSize: 10, fontWeight: '700' },
  welcomeRow: { alignItems: 'flex-end', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 18 },
  eyebrow: { fontSize: 11, fontWeight: '700', letterSpacing: 1.1, marginBottom: 5, textTransform: 'uppercase' },
  pageTitle: { fontSize: 29, fontWeight: '700', letterSpacing: -1 },
  editButton: { alignItems: 'center', borderRadius: 14, borderWidth: 1, flexDirection: 'row', gap: 7, height: 40, justifyContent: 'center', paddingHorizontal: 11 },
  editButtonText: { fontSize: 11, fontWeight: '700' },
  vehicleCard: { borderRadius: 25, flexDirection: 'row', justifyContent: 'space-between', minHeight: 142, overflow: 'hidden', padding: 22 },
  vehicleCardCopy: { justifyContent: 'space-between', zIndex: 1 },
  vehicleLabel: { color: '#A7C8C6', fontSize: 10, fontWeight: '700', letterSpacing: 1.1 },
  vehicleName: { color: '#FFFFFF', fontSize: 33, fontWeight: '700', letterSpacing: -1 },
  plateRow: { alignItems: 'center', flexDirection: 'row', gap: 7 },
  plateText: { color: '#D4E7E4', fontSize: 12, fontWeight: '600' },
  vehicleIllustration: { alignItems: 'center', justifyContent: 'center', marginRight: 7, position: 'relative', transform: [{ rotate: '-5deg' }] },
  illustrationGlow: { backgroundColor: '#16A6A0', borderRadius: 70, height: 95, opacity: 0.16, position: 'absolute', width: 95 },
  viewSwitch: { alignSelf: 'center', borderRadius: 14, flexDirection: 'row', marginVertical: 22, padding: 3, width: '74%' },
  viewSwitchButton: { alignItems: 'center', borderRadius: 11, flex: 1, paddingVertical: 9 },
  viewSwitchText: { fontSize: 12, fontWeight: '700' },
  mileageCard: { borderRadius: 22, borderWidth: 1, padding: 19 },
  mileageUpdateRow: { alignItems: 'center', flexDirection: 'row', gap: 8, marginTop: 16 },
  mileageInputWrap: { alignItems: 'center', backgroundColor: '#F3F8F6', borderColor: '#D2E1DC', borderRadius: 12, borderWidth: 1, flex: 1, flexDirection: 'row', gap: 8, minHeight: 43, paddingHorizontal: 12 },
  mileageInput: { flex: 1, fontSize: 14, fontWeight: '700', minHeight: 41 },
  mileageSaveButton: { alignItems: 'center', borderRadius: 12, height: 43, justifyContent: 'center', width: 45 },
  mileageError: { fontSize: 10, fontWeight: '600', marginTop: 5 },
  cardHeaderRow: { flexDirection: 'row', justifyContent: 'space-between' },
  cardEyebrow: { fontSize: 11, fontWeight: '600', marginBottom: 4 },
  mileageValueRow: { alignItems: 'baseline', flexDirection: 'row', gap: 7 },
  mileageValue: { fontSize: 32, fontWeight: '700', letterSpacing: -1 },
  mileageUnit: { fontSize: 13, fontWeight: '700' },
  mileageBadge: { alignItems: 'center', borderRadius: 12, flexDirection: 'row', gap: 4, height: 28, paddingHorizontal: 9 },
  mileageBadgeText: { fontSize: 11, fontWeight: '700' },
  progressTrack: { backgroundColor: '#E9F0ED', borderRadius: 5, height: 8, marginTop: 19, overflow: 'hidden' },
  progressFill: { borderRadius: 5, height: 8 },
  progressLabels: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 9 },
  progressText: { fontSize: 10, fontWeight: '600' },
  statGrid: { flexDirection: 'row', gap: 10, marginTop: 11, paddingRight: 2 },
  statPill: { alignItems: 'center', borderRadius: 17, borderWidth: 1, flexDirection: 'row', gap: 9, minWidth: 172, padding: 12 },
  statIcon: { alignItems: 'center', borderRadius: 10, height: 31, justifyContent: 'center', width: 31 },
  statCopy: { flex: 1 },
  statLabel: { fontSize: 9, fontWeight: '600', marginBottom: 2 },
  statValue: { fontSize: 12, fontWeight: '700' },
  addButton: { alignItems: 'center', borderRadius: 18, flexDirection: 'row', gap: 10, justifyContent: 'center', marginTop: 14, paddingHorizontal: 15, paddingVertical: 15 },
  addButtonIcon: { alignItems: 'center', borderColor: '#102A35', borderRadius: 9, borderWidth: 1, height: 27, justifyContent: 'center', width: 27 },
  addButtonText: { flex: 1, fontSize: 14, fontWeight: '700' },
  sectionHeader: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 11, marginTop: 27 },
  sectionTitle: { fontSize: 17, fontWeight: '700', letterSpacing: -0.3 },
  seeAll: { fontSize: 11, fontWeight: '700' },
  activityRow: { alignItems: 'center', borderRadius: 16, borderWidth: 1, flexDirection: 'row', gap: 11, marginBottom: 9, padding: 12 },
  activityIcon: { alignItems: 'center', borderRadius: 12, height: 39, justifyContent: 'center', width: 39 },
  activityCopy: { flex: 1 },
  activityTitle: { fontSize: 13, fontWeight: '700', marginBottom: 3 },
  activityMeta: { fontSize: 10, fontWeight: '500' },
  activityCost: { fontSize: 12, fontWeight: '700' },
  emptyState: { alignItems: 'center', borderRadius: 17, borderWidth: 1, padding: 24 },
  emptyTitle: { fontSize: 14, fontWeight: '700', marginTop: 10 },
  emptyHint: { fontSize: 11, lineHeight: 17, marginTop: 5, maxWidth: 250, textAlign: 'center' },
  historyHeader: { alignItems: 'baseline', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 13 },
  recordCount: { fontSize: 11, fontWeight: '600' },
  historyCard: { alignItems: 'center', borderRadius: 17, borderWidth: 1, flexDirection: 'row', gap: 11, marginBottom: 10, padding: 13 },
  historyCopy: { flex: 1 },
  historyCost: { fontSize: 12, fontWeight: '700' },
  noteText: { fontSize: 10, marginTop: 6 },
  offlineNote: { alignItems: 'center', flexDirection: 'row', gap: 6, justifyContent: 'center', marginTop: 25 },
  offlineText: { fontSize: 10, fontWeight: '600' },
  modalRoot: { flex: 1 },
  modalHeader: { alignItems: 'center', borderBottomWidth: 1, flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 17 },
  modalEyebrow: { fontSize: 10, fontWeight: '700', letterSpacing: 1.1, textTransform: 'uppercase' },
  modalTitle: { fontSize: 23, fontWeight: '700', marginTop: 3 },
  closeButton: { alignItems: 'center', borderRadius: 14, height: 36, justifyContent: 'center', width: 36 },
  modalContent: { padding: 20 },
  fieldLabel: { fontSize: 12, fontWeight: '700', marginBottom: 8, marginTop: 16 },
  typeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  typeChoice: { alignItems: 'center', borderRadius: 13, borderWidth: 1, gap: 6, justifyContent: 'center', minHeight: 66, paddingHorizontal: 8, width: '31.8%' },
  typeChoiceText: { fontSize: 10, fontWeight: '700', textAlign: 'center' },
  input: { borderRadius: 13, borderWidth: 1, fontSize: 14, minHeight: 50, paddingHorizontal: 14 },
  notesInput: { minHeight: 92, paddingTop: 14, textAlignVertical: 'top' },
  errorText: { fontSize: 11, fontWeight: '600', marginTop: 6 },
  fieldRow: { flexDirection: 'row', gap: 10 },
  fieldHalf: { flex: 1 },
  primaryButton: { alignItems: 'center', borderRadius: 15, flexDirection: 'row', gap: 9, justifyContent: 'center', marginTop: 25, minHeight: 52, paddingHorizontal: 18 },
  primaryButtonText: { fontSize: 14, fontWeight: '700' },
  cancelButton: { alignItems: 'center', paddingVertical: 16 },
  cancelText: { fontSize: 13, fontWeight: '700' },
  settingsLanguageRow: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  settingsLanguageButton: { borderRadius: 13, borderWidth: 1, flex: 1, minHeight: 46, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 },
  settingsLanguageText: { fontSize: 11, fontWeight: '700', textAlign: 'center' },
  settingsRow: { alignItems: 'center', borderRadius: 16, borderWidth: 1, flexDirection: 'row', gap: 11, marginTop: 10, padding: 13 },
  settingsIcon: { alignItems: 'center', borderRadius: 11, height: 38, justifyContent: 'center', width: 38 },
  settingsCopy: { flex: 1 },
  settingsTitle: { fontSize: 13, fontWeight: '700' },
  settingsSubtitle: { fontSize: 9, lineHeight: 14, marginTop: 3 },
  versionText: { fontSize: 10, fontWeight: '600', marginTop: 22, textAlign: 'center' },
  privacyContent: { padding: 20 },
  privacyText: { fontSize: 13, lineHeight: 21, marginBottom: 18 },
});