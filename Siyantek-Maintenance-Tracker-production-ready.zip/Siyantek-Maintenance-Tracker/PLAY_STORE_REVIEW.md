# Siyantek — Play Store release review

## Production work completed
- Removed demo/sample vehicle and maintenance records from the fresh-install state.
- Added first-launch vehicle setup.
- Hardened AsyncStorage restoration against malformed data.
- Validated vehicle and maintenance inputs.
- Added Settings with language selection, privacy information and local-data deletion.
- Added English, French and Arabic UI with Arabic RTL support.
- Blocked unused sensitive Android permissions.
- Kept the app offline-first; no account creation is implemented.
- Added privacy policy source and hosted-HTML template.
- Added Play Store listing draft and release checklist.
- Android package ID: `com.siyantek.maintenance`.
- Production EAS profile outputs an Android App Bundle (AAB).
- Android edge-to-edge is explicitly enabled for API 36 behavior.

## Current Google Play requirements
As of August 31, 2026, new apps and app updates submitted to Google Play must target Android 16 / API 36 or higher. Expo SDK 57 targets compile/target SDK 36. Google Play also requires apps containing native code to support 64-bit architectures and 16 KB memory page sizes.

## What still requires the developer account / external hosting
1. Publish `artifacts/siyantek/docs/privacy-policy.html` at a stable HTTPS URL.
2. Enter the final support email and verified developer information in Play Console.
3. Link/create the Expo EAS project and Android signing credentials.
4. Run the production EAS build and obtain the signed AAB.
5. Test the signed build on physical Android devices and review the Play pre-launch report.
6. Complete Play Console forms: Data Safety, Content Rating, Target Audience, Ads and app-access/reviewer instructions when applicable.
7. Upload screenshots and feature graphic and complete store metadata.

## Important
Google Play acceptance cannot be guaranteed by code changes alone. Review also depends on the final signed binary, store metadata, privacy-policy URL, developer verification and policy declarations.

## Suggested production commands
From `artifacts/siyantek` after installing dependencies and logging into Expo/EAS:

```bash
pnpm install --frozen-lockfile
pnpm exec expo-doctor
pnpm run typecheck
pnpm exec eas build --platform android --profile production
```

Then upload the resulting `.aab` to an **Internal testing** track first.
